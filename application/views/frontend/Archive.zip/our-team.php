<?php include_once('./include/header.php') ?>

<section class="team_banner breadcrumb-banner ">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="banner_content text-center">
					<h4 class="text-primary">
						Our Team
					</h4>
					<h1 class="text-white about-heading">
						Our Expert Crew Meet Our Leadership
					</h1>
					<p class="text-white">
						Est sit amet facilisis magna etiam tempor orci eu lobortis. Eu nisl nunc mi ipsum faucibus vitae.
					</p>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="team-listing">
	<div class="container">
		<div class="row gy-1">
			<div class="col-lg-3 col-md-6">
				<div class="teams_card two">
					<img src="images/teams.jpeg" class="team_member_image">
					<h4 class="teama_member_name">
						Jacob C. Huffman
					</h4>
					<p class="team_member_des">Designation</p>
					<div class="team_social">
						<a href="#"> <i class="fa-brands fa-facebook"></i></a>
			            <a href="#"><i class="fa-brands fa-twitter"></i></a>
			            <a href="#"> <i class="fa-brands fa-linkedin"></i></a>
			            <a href="#"> <i class="fa-brands fa-instagram"></i></a>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="teams_card two">
					<img src="images/teams.jpeg" class="team_member_image">
					<h4 class="teama_member_name">
						Jacob C. Huffman
					</h4>
					<p class="team_member_des">Designation</p>
					<div class="team_social">
						<a href="#"> <i class="fa-brands fa-facebook"></i></a>
			            <a href="#"><i class="fa-brands fa-twitter"></i></a>
			            <a href="#"> <i class="fa-brands fa-linkedin"></i></a>
			            <a href="#"> <i class="fa-brands fa-instagram"></i></a>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="teams_card two">
					<img src="images/teams.jpeg" class="team_member_image">
					<h4 class="teama_member_name">
						Jacob C. Huffman
					</h4>
					<p class="team_member_des">Designation</p>
					<div class="team_social">
						<a href="#"> <i class="fa-brands fa-facebook"></i></a>
			            <a href="#"><i class="fa-brands fa-twitter"></i></a>
			            <a href="#"> <i class="fa-brands fa-linkedin"></i></a>
			            <a href="#"> <i class="fa-brands fa-instagram"></i></a>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="teams_card two">
					<img src="images/teams.jpeg" class="team_member_image">
					<h4 class="teama_member_name">
						Jacob C. Huffman
					</h4>
					<p class="team_member_des">Designation</p>
					<div class="team_social">
						<a href="#"> <i class="fa-brands fa-facebook"></i></a>
			            <a href="#"><i class="fa-brands fa-twitter"></i></a>
			            <a href="#"> <i class="fa-brands fa-linkedin"></i></a>
			            <a href="#"> <i class="fa-brands fa-instagram"></i></a>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="teams_card two">
					<img src="images/teams.jpeg" class="team_member_image">
					<h4 class="teama_member_name">
						Jacob C. Huffman
					</h4>
					<p class="team_member_des">Designation</p>
					<div class="team_social">
						<a href="#"> <i class="fa-brands fa-facebook"></i></a>
			            <a href="#"><i class="fa-brands fa-twitter"></i></a>
			            <a href="#"> <i class="fa-brands fa-linkedin"></i></a>
			            <a href="#"> <i class="fa-brands fa-instagram"></i></a>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="teams_card two">
					<img src="images/teams.jpeg" class="team_member_image">
					<h4 class="teama_member_name">
						Jacob C. Huffman
					</h4>
					<p class="team_member_des">Designation</p>
					<div class="team_social">
						<a href="#"> <i class="fa-brands fa-facebook"></i></a>
			            <a href="#"><i class="fa-brands fa-twitter"></i></a>
			            <a href="#"> <i class="fa-brands fa-linkedin"></i></a>
			            <a href="#"> <i class="fa-brands fa-instagram"></i></a>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="teams_card two">
					<img src="images/teams.jpeg" class="team_member_image">
					<h4 class="teama_member_name">
						Jacob C. Huffman
					</h4>
					<p class="team_member_des">Designation</p>
					<div class="team_social">
						<a href="#"> <i class="fa-brands fa-facebook"></i></a>
			            <a href="#"><i class="fa-brands fa-twitter"></i></a>
			            <a href="#"> <i class="fa-brands fa-linkedin"></i></a>
			            <a href="#"> <i class="fa-brands fa-instagram"></i></a>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="teams_card two">
					<img src="images/teams.jpeg" class="team_member_image">
					<h4 class="teama_member_name">
						Jacob C. Huffman
					</h4>
					<p class="team_member_des">Designation</p>
					<div class="team_social">
						<a href="#"> <i class="fa-brands fa-facebook"></i></a>
			            <a href="#"><i class="fa-brands fa-twitter"></i></a>
			            <a href="#"> <i class="fa-brands fa-linkedin"></i></a>
			            <a href="#"> <i class="fa-brands fa-instagram"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php include_once('./include/footer.php') ?>